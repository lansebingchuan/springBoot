package com.zht.test.service;

/**
 * @author zhanghaitao
 * @date 2020/3/20 0020
 */
public interface UserService {

    /**
     * 添加用户
     */
    void addUser();

}
