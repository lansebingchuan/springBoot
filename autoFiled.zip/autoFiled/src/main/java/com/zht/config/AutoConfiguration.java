package com.zht.config;

import org.springframework.context.annotation.Configuration;

/**
 * 自动化启动配置类
 *
 * @author zhanghaitao
 * @date 2020/3/20 0020
 */
@Configuration
public class AutoConfiguration {


}
